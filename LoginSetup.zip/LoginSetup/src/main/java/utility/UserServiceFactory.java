package utility;

import service.UserService;
import service.UserServiceInterface;

public class UserServiceFactory {

	public static UserServiceInterface createObject() {
		// TODO Auto-generated method stub
		
		UserServiceInterface pci = new UserService();
		return pci;
	}

}
