package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import model.User;
import service.UserServiceInterface;
import utility.UserServiceFactory;

public class UserController implements UserControllerInterface {

	public UserController()
	{
		
			
	}
	public void Login() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your E-Mail:");
		String email = sc.next();
		System.out.println("Enter your password:");
		String pword = sc.next();
		
		User u = new User();
		u.setEmail(email);
		u.setPassword(pword);
		
		UserServiceInterface usi = UserServiceFactory.createObject();
		
		usi.createUser(u);
		
		System.out.println("User Created!");
		
		
	}

	public void Signup() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your E-Mail:");
		String email = sc.next();
		System.out.println("Enter your password:");
		String pword = sc.next();
		
		User u = new User();
		u.setEmail(email);
		u.setPassword(pword);
		
		UserServiceInterface usi = UserServiceFactory.createObject();
		
		int i=usi.checkUser(u);
		
		if(i==1)
		{
			System.out.println("Welcome!");
		}
		
		
		// TODO Auto-generated method stub
		
	}

}
