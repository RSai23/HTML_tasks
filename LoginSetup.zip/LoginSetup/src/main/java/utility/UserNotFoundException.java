package utility;

@SuppressWarnings("serial")
public class UserNotFoundException extends RuntimeException{
	
	public UserNotFoundException (String str)  
    {  
        super(str);  
    } 

}
