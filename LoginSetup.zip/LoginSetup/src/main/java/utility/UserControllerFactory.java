package utility;
import controller.UserController;
import controller.UserControllerInterface;

public class UserControllerFactory {

	public static UserControllerInterface createObject() {
		// TODO Auto-generated method stub
		
		UserControllerInterface pci = new UserController();
		return pci;
	}

}
