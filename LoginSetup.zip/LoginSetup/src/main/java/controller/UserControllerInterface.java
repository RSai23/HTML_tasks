package controller;

public interface UserControllerInterface {
	
	public void Login();
	public void Signup();

}
