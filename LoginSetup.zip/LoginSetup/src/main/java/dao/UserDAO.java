package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.User;
import utility.UserNotFoundException;

public class UserDAO implements UserDAOInterface {


	public void createUser(User u) {
		// TODO Auto-generated method stub
		
		int i = 0;

		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/hsbc", "root", "Rs@iram23");

			PreparedStatement ps = con.prepareStatement("insert into user values(?,?)");
			ps.setString(1, u.getEmail());
			ps.setString(2, u.getPassword());

			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return;
		
		
	}

	public int checkUser(User u) {
		// TODO Auto-generated method stub
		int i = 0;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/hsbc", "root", "Rs@iram23");


			PreparedStatement ps = con.prepareStatement("select * from user where email=?");
			ps.setString(1, u.getEmail());

			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				i++;
			}
			
			if(i==0)
			{
				throw new UserNotFoundException("No user found with given arguments");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return i;
	}

}
