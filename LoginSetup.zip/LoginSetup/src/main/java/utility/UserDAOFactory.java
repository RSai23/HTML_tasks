package utility;

import dao.UserDAO;
import dao.UserDAOInterface;

public class UserDAOFactory {

	public static UserDAOInterface createObject() {
		// TODO Auto-generated method stub
		UserDAOInterface udi = new UserDAO();
		return udi;
	}

}
