package view;

import java.util.Scanner;


import controller.UserControllerInterface;
import utility.UserControllerFactory;

public class userView {
	
	public static void main(String args[])
	{
			String ss="y";
		
			while(ss.equals("y")) {
			Scanner sc = new Scanner(System.in);
			System.out.println("*****************MAIN MENU*****************");
			System.out.println("press 1 to Login");
			System.out.println("press 2 to Signup");
			
	
			System.out.println("enter your choice");
			int c = sc.nextInt();
	
			UserControllerInterface uc = UserControllerFactory.createObject();
	
			switch (c) {
			case 1:
				uc.Login();
				break;
			case 2:
				uc.Signup();
				break;
			default:
				System.out.println("wrong choice");
			}
			System.out.println("do you want to continue press y/n");
			ss=sc.next();
		}

	}
}
