package service;

import model.User;

public interface UserServiceInterface {

	void createUser(User u);

	int checkUser(User u);

}
