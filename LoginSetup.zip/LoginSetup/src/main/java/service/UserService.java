package service;

import dao.UserDAOInterface;
import model.User;
import utility.UserDAOFactory;

public class UserService implements UserServiceInterface {

	public void createUser(User u) {
		
		UserDAOInterface udi = UserDAOFactory.createObject();
		udi.createUser(u);
		// TODO Auto-generated method stub
		
	}

	public int checkUser(User u) {
		// TODO Auto-generated method stub
		UserDAOInterface udi = UserDAOFactory.createObject();
		return udi.checkUser(u);
		
		
	}

}
