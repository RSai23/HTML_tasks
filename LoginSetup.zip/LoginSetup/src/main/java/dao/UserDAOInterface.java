package dao;

import model.User;
import utility.UserNotFoundException;

public interface UserDAOInterface {

	void createUser(User u);

	int checkUser(User u) throws UserNotFoundException;

}
